# Bot Loja Discord com Pix

## Instruções básicas:
1. Configure o arquivo `.env` com seu DISCORD_TOKEN e CHAVE PIX do Mercado Pago.
2. Use `produtos.json` para adicionar seus serviços.
3. Suba o projeto no Render.com com as variáveis de ambiente corretas.
